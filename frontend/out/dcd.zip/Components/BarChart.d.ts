/// <reference types="react" />
interface Props {
    data: {
        x: (number | string)[];
        y: number[];
    };
    title: string;
}
declare function BarChart({ data, title }: Props): JSX.Element;
export default BarChart;
