import { Dispatch, SetStateAction } from "react";
import { Project } from "../models/Project";
import { Case } from "../models/Case";
interface Props {
    setProject: Dispatch<SetStateAction<Project | undefined>>;
    caseItem: Case | undefined;
    setCase: Dispatch<SetStateAction<Case | undefined>>;
}
declare const CaseDescription: ({ setProject, caseItem, setCase, }: Props) => JSX.Element;
export default CaseDescription;
