import { Dispatch, SetStateAction } from "react";
interface Props {
    setMaturity: Dispatch<SetStateAction<Components.Schemas.Maturity | undefined>>;
    currentValue: Components.Schemas.Maturity | undefined;
    setHasChanges?: Dispatch<SetStateAction<boolean>>;
}
declare const Maturity: ({ setMaturity, currentValue, setHasChanges, }: Props) => JSX.Element;
export default Maturity;
