import { Dispatch, SetStateAction } from "react";
import AssetTypeEnum from "../models/assets/AssetTypeEnum";
import { IAsset } from "../models/assets/IAsset";
import { Project } from "../models/Project";
import { IAssetService } from "../Services/IAssetService";
interface Props {
    name: string;
    setHasChanges: Dispatch<SetStateAction<boolean>>;
    hasChanges: boolean;
    setAsset: Dispatch<SetStateAction<any | undefined>>;
    setProject: Dispatch<SetStateAction<Project | undefined>>;
    asset: IAsset;
    assetService: IAssetService;
    assetType: AssetTypeEnum;
}
declare const Save: ({ name, setHasChanges, hasChanges, setAsset, setProject, asset, assetService, assetType, }: Props) => JSX.Element;
export default Save;
