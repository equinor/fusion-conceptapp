import { Dispatch, SetStateAction } from "react";
interface Props {
    setValue?: Dispatch<SetStateAction<number | undefined>>;
    value: number | undefined;
    setHasChanges?: Dispatch<SetStateAction<boolean>>;
    integer: boolean;
    disabled?: boolean;
    label: string;
}
declare const NumberInput: ({ setValue, value, setHasChanges, integer, disabled, label, }: Props) => JSX.Element;
export default NumberInput;
