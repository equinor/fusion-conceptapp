import { Dispatch, SetStateAction } from "react";
import { Case } from "../models/Case";
import { Project } from "../models/Project";
interface Props {
    caseItem: Case | undefined;
    setProductionStrategyOverview: Dispatch<SetStateAction<Components.Schemas.ProductionStrategyOverview>>;
    setProject: Dispatch<SetStateAction<Project | undefined>>;
    currentValue: Components.Schemas.ProductionStrategyOverview;
}
declare const ProductionStrategyOverview: ({ caseItem, setProductionStrategyOverview, setProject, currentValue, }: Props) => JSX.Element;
export default ProductionStrategyOverview;
