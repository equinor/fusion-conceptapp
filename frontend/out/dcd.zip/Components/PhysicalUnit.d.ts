import { Dispatch, SetStateAction } from "react";
import { Project } from "../models/Project";
interface Props {
    project: Project;
    setPhysicalUnit: Dispatch<SetStateAction<Components.Schemas.PhysUnit>>;
    setProject: Dispatch<SetStateAction<Project | undefined>>;
    currentValue: Components.Schemas.PhysUnit;
}
declare const PhysicalUnit: ({ project, setPhysicalUnit, setProject, currentValue, }: Props) => JSX.Element;
export default PhysicalUnit;
