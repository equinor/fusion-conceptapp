import { Dispatch, SetStateAction } from "react";
import { Project } from "../models/Project";
import { Case } from "../models/Case";
interface Props {
    project: Project;
    setProject: Dispatch<SetStateAction<Project | undefined>>;
    caseItem: Case | undefined;
    setCase: Dispatch<SetStateAction<Case | undefined>>;
    caseId: string | undefined;
}
declare const CaseAsset: ({ project, setProject, caseItem, setCase, caseId, }: Props) => JSX.Element;
export default CaseAsset;
