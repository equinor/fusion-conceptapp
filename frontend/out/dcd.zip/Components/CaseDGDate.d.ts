import { Dispatch, SetStateAction } from "react";
import { Project } from "../models/Project";
import { Case } from "../models/Case";
import DGEnum from "../models/DGEnum";
interface Props {
    setProject: Dispatch<SetStateAction<Project | undefined>>;
    caseItem: Case | undefined;
    setCase: Dispatch<SetStateAction<Case | undefined>>;
    dGType: DGEnum;
    dGName: string;
}
declare const CaseDGDate: ({ setProject, caseItem, setCase, dGType, dGName, }: Props) => JSX.Element;
export default CaseDGDate;
