import { FunctionComponent } from "react";
declare type Props = {};
export declare const Portal: FunctionComponent<Props>;
export {};
