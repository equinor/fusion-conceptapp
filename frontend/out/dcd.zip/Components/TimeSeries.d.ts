import { Dispatch, SetStateAction } from "react";
import { ITimeSeries } from "../models/ITimeSeries";
interface Props {
    dG4Year: number | undefined;
    setTimeSeries: Dispatch<SetStateAction<ITimeSeries | undefined>>;
    setHasChanges: Dispatch<SetStateAction<boolean>>;
    timeSeriesTitle: string;
    firstYear: number | undefined;
    lastYear: number | undefined;
    setFirstYear: Dispatch<SetStateAction<number | undefined>>;
    setLastYear: Dispatch<SetStateAction<number | undefined>>;
    timeSeries: ITimeSeries | undefined;
}
declare const TimeSeries: ({ dG4Year, setTimeSeries, setHasChanges, timeSeries, timeSeriesTitle, firstYear, lastYear, setFirstYear, setLastYear, }: Props) => JSX.Element;
export default TimeSeries;
