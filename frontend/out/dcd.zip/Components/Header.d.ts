/// <reference types="react" />
interface Props {
    name: string | undefined;
}
declare function Header({ name }: Props): JSX.Element;
export default Header;
