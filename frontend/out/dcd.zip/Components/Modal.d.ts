import { FunctionComponent } from "react";
declare type Props = {
    title: string;
    isOpen: boolean;
    shards: any[];
};
export declare const Modal: FunctionComponent<Props>;
export {};
