import { Dispatch, SetStateAction } from "react";
import { Case } from "../models/Case";
import { Project } from "../models/Project";
interface Props {
    caseItem: Case | undefined;
    setArtificialLift: Dispatch<SetStateAction<Components.Schemas.ArtificialLift>>;
    setProject: Dispatch<SetStateAction<Project | undefined>>;
    currentValue: Components.Schemas.ArtificialLift;
}
declare const CaseArtificialLift: ({ caseItem, setArtificialLift, setProject, currentValue, }: Props) => JSX.Element;
export default CaseArtificialLift;
