import { Dispatch, SetStateAction } from "react";
import { Project } from "../models/Project";
interface Props {
    project: Project;
    setCurrency: Dispatch<SetStateAction<Components.Schemas.Currency>>;
    setProject: Dispatch<SetStateAction<Project | undefined>>;
    currentValue: Components.Schemas.Currency;
}
declare const Currency: ({ project, setCurrency, setProject, currentValue, }: Props) => JSX.Element;
export default Currency;
