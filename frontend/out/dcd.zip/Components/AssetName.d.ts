import { Dispatch, SetStateAction } from "react";
interface Props {
    setName: Dispatch<SetStateAction<string>>;
    name: string;
    setHasChanges: Dispatch<SetStateAction<boolean>>;
}
declare const AssetName: ({ setName, name, setHasChanges, }: Props) => JSX.Element;
export default AssetName;
