import { Dispatch, SetStateAction } from "react";
interface Props {
    setCurrency: Dispatch<SetStateAction<Components.Schemas.Currency>>;
    setHasChanges: Dispatch<SetStateAction<boolean>>;
    currentValue: Components.Schemas.Currency;
}
declare const AssetCurrency: ({ setCurrency, setHasChanges, currentValue, }: Props) => JSX.Element;
export default AssetCurrency;
