/// <reference types="react" />
interface Props {
    onClose: () => void;
    onImport: (input: string, year: number) => void;
}
declare function Import({ onClose, onImport }: Props): JSX.Element;
export default Import;
