/// <reference types="react" />
import { IconData } from "@equinor/eds-icons";
interface Props {
    title: string;
    isSelected: boolean;
    icon?: IconData;
    isOpen?: boolean;
    onClick?: () => void;
    padding?: string;
}
declare function MenuItem({ title, isSelected, icon, isOpen, onClick, padding, }: Props): JSX.Element;
export default MenuItem;
