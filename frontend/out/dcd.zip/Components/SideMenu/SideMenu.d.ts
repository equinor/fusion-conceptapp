/// <reference types="react" />
export declare const projects: {
    name: string;
    id: string;
    createdDate: number;
    cases: {
        title: string;
        id: string;
        capex: number;
        drillex: number;
        ur: number;
    }[];
}[];
declare function SideMenu(): JSX.Element | null;
export default SideMenu;
