/// <reference types="react" />
import { Project } from "../../models/Project";
export declare enum ProjectMenuItemType {
    OVERVIEW = "Overview",
    CASES = "Cases"
}
interface Props {
    project: Project;
}
declare function ProjectMenu({ project }: Props): JSX.Element;
export default ProjectMenu;
