/// <reference types="react" />
import { IconData } from "@equinor/eds-icons";
export declare type ProjectMenuItem = {
    name: string;
    icon: IconData;
};
interface Props {
    item: ProjectMenuItem;
    projectId: string;
    subItems?: Components.Schemas.CaseDto[];
}
declare function ProjectMenuItemComponent({ item, projectId, subItems }: Props): JSX.Element;
export default ProjectMenuItemComponent;
