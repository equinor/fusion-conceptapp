import React from "react";
interface Props {
    assetName: string;
    linkAsset: (event: React.ChangeEvent<HTMLSelectElement>, link: any) => void;
    link: string;
    currentValue: string | undefined;
    values: JSX.Element[];
}
declare const LinkAsset: ({ assetName, linkAsset, link, currentValue, values, }: Props) => JSX.Element;
export default LinkAsset;
