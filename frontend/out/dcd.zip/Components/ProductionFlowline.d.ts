import { Dispatch, SetStateAction } from "react";
interface Props {
    setProductionFlowline: Dispatch<SetStateAction<Components.Schemas.ProductionFlowline | undefined>>;
    currentValue: Components.Schemas.ProductionFlowline | undefined;
    setHasChanges?: Dispatch<SetStateAction<boolean>>;
}
declare const ProductionFlowline: ({ setProductionFlowline, currentValue, setHasChanges, }: Props) => JSX.Element;
export default ProductionFlowline;
