/// <reference types="react" />
import "react-datasheet/lib/react-datasheet.css";
import "./style.css";
export interface CellValue {
    value: number | string;
    readOnly?: boolean;
}
interface Props {
    columns: string[];
    gridData: any;
    onCellsChanged: any;
    dG4Year: string;
}
declare function DataTable({ columns, gridData, onCellsChanged, dG4Year, }: Props): JSX.Element;
export default DataTable;
