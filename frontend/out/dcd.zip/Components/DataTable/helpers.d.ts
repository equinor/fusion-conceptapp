import { CellValue } from "./DataTable";
export declare const generateEmptyGridWithRowTitles: (rowTitles: string[]) => CellValue[][];
export declare const replaceOldData: (oldGridData: CellValue[][], changes: {
    cell: {
        value: number;
    };
    col: number;
    row: number;
    value: string;
}[]) => CellValue[][];
export declare const generateNewGrid: (data: {
    [key: string]: string;
}[], rowTitles: string[]) => {
    newGridData: CellValue[][];
    newColumns: string[];
};
export declare const getColumnAbsoluteYears: (dG4Year?: number | undefined, costProfile?: any) => string[];
export declare const buildGridData: (costProfile?: any) => {
    value: number;
    readOnly?: boolean | undefined;
}[][];
export declare const buildZeroGridData: (zeroes?: any) => {
    value: number;
    readOnly?: boolean | undefined;
}[][];
