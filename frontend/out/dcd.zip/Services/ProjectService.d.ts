import { Project } from "../models/Project";
import { __BaseService } from "./__BaseService";
export declare class __ProjectService extends __BaseService {
    getProjects(): Promise<Project[]>;
    getProjectByID(id: string): Promise<Project>;
    createProject(project: Components.Schemas.ProjectDto): Promise<any>;
    updateProject(body: Components.Schemas.ProjectDto): Promise<Project>;
}
export declare function GetProjectService(): __ProjectService;
