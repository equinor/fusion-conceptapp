import { __BaseService } from "./__BaseService";
import { Project } from "../models/Project";
import { IAssetService } from "./IAssetService";
export declare class __DrainageStrategyService extends __BaseService implements IAssetService {
    create(sourceCaseId: string, body: Components.Schemas.DrainageStrategyDto): Promise<Project>;
    update(body: Components.Schemas.DrainageStrategyDto): Promise<Project>;
}
export declare function GetDrainageStrategyService(): __DrainageStrategyService;
