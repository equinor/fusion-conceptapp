import { __BaseService } from "./__BaseService";
import { Project } from "../models/Project";
declare class __STEAService extends __BaseService {
    excelToSTEA(project: Project): Promise<void>;
}
export declare function GetSTEAService(): __STEAService;
export {};
