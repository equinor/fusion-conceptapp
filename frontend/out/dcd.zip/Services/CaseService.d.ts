import { __BaseService } from "./__BaseService";
import { Project } from "../models/Project";
declare class __CaseService extends __BaseService {
    createCase(data: Components.Schemas.CaseDto): Promise<Project>;
    updateCase(body: Components.Schemas.CaseDto): Promise<Project>;
}
export declare const CaseService: __CaseService;
export declare function GetCaseService(): __CaseService;
export {};
