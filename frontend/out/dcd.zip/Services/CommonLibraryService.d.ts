import { __BaseService } from "./__BaseService";
export declare class __CommonLibraryService extends __BaseService {
    getProjects(): Promise<Components.Schemas.CommonLibraryProjectDto[]>;
}
export declare function GetCommonLibraryService(): __CommonLibraryService;
