import { __BaseService } from "./__BaseService";
import { Project } from "../models/Project";
import { IAssetService } from "./IAssetService";
export declare class __TopsideService extends __BaseService implements IAssetService {
    create(sourceCaseId: string, body: Components.Schemas.TopsideDto): Promise<Project>;
    update(body: Components.Schemas.TopsideDto): Promise<Project>;
}
export declare function GetTopsideService(): __TopsideService;
