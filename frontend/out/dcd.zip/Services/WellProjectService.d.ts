import { __BaseService } from "./__BaseService";
import { Project } from "../models/Project";
import { IAssetService } from "./IAssetService";
export declare class __WellProjectService extends __BaseService implements IAssetService {
    create(sourceCaseId: string, body: Components.Schemas.WellProjectDto): Promise<Project>;
    update(body: Components.Schemas.WellProjectDto): Promise<Project>;
}
export declare function GetWellProjectService(): __WellProjectService;
