import { __BaseService } from "./__BaseService";
import { Project } from "../models/Project";
import { IAssetService } from "./IAssetService";
export declare class __SurfService extends __BaseService implements IAssetService {
    create(sourceCaseId: string, body: Components.Schemas.SurfDto): Promise<Project>;
    update(body: Components.Schemas.SurfDto): Promise<Project>;
}
export declare function GetSurfService(): __SurfService;
