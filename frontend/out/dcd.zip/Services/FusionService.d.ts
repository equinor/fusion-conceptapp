import { __BaseService } from "./__BaseService";
export declare class __FusionService extends __BaseService {
    getFusionProjects(): Promise<any>;
}
export declare function GetFusionService(): __FusionService;
