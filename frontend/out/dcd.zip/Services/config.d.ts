export declare type ServiceConfig = {
    BASE_URL: string;
    accessToken?: string;
    headers?: Record<string, string>;
};
export declare const config: Readonly<{
    CaseService: {
        BASE_URL: string;
    };
    CommonLibraryService: {
        BASE_URL: string;
    };
    FusionService: {
        BASE_URL: string;
    };
    ProjectService: {
        BASE_URL: string;
    };
    DrainageStrategyService: {
        BASE_URL: string;
    };
    ExplorationService: {
        BASE_URL: string;
    };
    WellProjectService: {
        BASE_URL: string;
    };
    SurfService: {
        BASE_URL: string;
    };
    TopsideService: {
        BASE_URL: string;
    };
    SubstructureService: {
        BASE_URL: string;
    };
    TransportService: {
        BASE_URL: string;
    };
    STEAService: {
        BASE_URL: string;
    };
}>;
