import { __BaseService } from "./__BaseService";
import { Project } from "../models/Project";
import { IAssetService } from "./IAssetService";
export declare class __SubstructureService extends __BaseService implements IAssetService {
    create(sourceCaseId: string, body: Components.Schemas.SubstructureDto): Promise<Project>;
    update(body: Components.Schemas.SubstructureDto): Promise<Project>;
}
export declare function GetSubstructureService(): __SubstructureService;
