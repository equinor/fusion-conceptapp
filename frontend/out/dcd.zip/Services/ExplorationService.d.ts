import { __BaseService } from "./__BaseService";
import { Project } from "../models/Project";
import { IAssetService } from "./IAssetService";
export declare class __ExplorationService extends __BaseService implements IAssetService {
    create(sourceCaseId: string, body: Components.Schemas.ExplorationDto): Promise<Project>;
    update(body: Components.Schemas.ExplorationDto): Promise<Project>;
}
export declare function GetExplorationService(): __ExplorationService;
