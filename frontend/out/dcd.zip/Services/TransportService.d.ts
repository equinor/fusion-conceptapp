import { __BaseService } from "./__BaseService";
import { Project } from "../models/Project";
import { IAssetService } from "./IAssetService";
export declare class __TransportService extends __BaseService implements IAssetService {
    create(sourceCaseId: string, body: Components.Schemas.TransportDto): Promise<Project>;
    update(body: Components.Schemas.TransportDto): Promise<Project>;
}
export declare function GetTransportService(): __TransportService;
