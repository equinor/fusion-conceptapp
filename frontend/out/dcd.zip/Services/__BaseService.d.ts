import { AxiosRequestConfig, ResponseType } from "axios";
import { ServiceConfig } from "./config";
declare type RequestOptions = {
    credentials?: RequestCredentials;
    headers?: Record<string, string>;
    method?: "GET" | "DELETE" | "HEAD" | "OPTIONS" | "POST" | "PUT" | "PATCH" | "PURGE" | "LINK" | "UNLINK";
    body?: Record<string, any>;
};
export declare class __BaseService {
    private config;
    private client;
    constructor(config: ServiceConfig);
    private request;
    private requestExcel;
    protected postWithParams(path: string, options?: RequestOptions, requestQuery?: AxiosRequestConfig): Promise<any>;
    protected postExcel<T = any>(path: string, responseType?: ResponseType, options?: RequestOptions): Promise<T>;
    protected get<T = any>(path: string, options?: RequestOptions): Promise<T>;
    protected post<T = any>(path: string, options?: RequestOptions): Promise<T>;
    protected put<T = any>(path: string, options?: RequestOptions): Promise<T>;
}
export {};
