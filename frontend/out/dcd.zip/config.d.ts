export declare const AzureAd: {
    clientId: string;
    authority: string;
    redirectUri: string | undefined;
};
export declare const fusionApiScope: string[];
export declare const appInsightsInstrumentationKey = "f218caa9-c1a4-4c31-973b-c787a90af4ce";
export declare function RetrieveConfigFromAzure(): Promise<{
    azureAd: {
        clientId: string;
        authority: string;
        redirectUri: string;
    };
    backendUrl: string;
    applicationInsightInstrumentationKey: string;
    msal: {
        auth: {
            clientId: string;
            authority: string;
            redirectUri: string;
        };
        cache: {
            cacheLocation: string;
            storeAuthStateInCookie: boolean;
        };
        system: {
            loggerOptions: {
                loggerCallback: (level: any, message: any, containsPii: any) => void;
            };
        };
    };
}>;
