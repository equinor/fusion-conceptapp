export declare const loginRequest: {
    scopes: string[];
};
export declare const graphConfig: {
    graphMeEndpoint: string;
};
