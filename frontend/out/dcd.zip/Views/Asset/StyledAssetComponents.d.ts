/// <reference types="react" />
export declare const AssetHeader: import("styled-components").StyledComponent<"div", any, {}, never>;
export declare const AssetViewDiv: import("styled-components").StyledComponent<"div", any, {}, never>;
export declare const Wrapper: import("styled-components").StyledComponent<"div", any, {}, never>;
export declare const WrapperColumn: import("styled-components").StyledComponent<"div", any, {}, never>;
export declare const SaveButton: import("styled-components").StyledComponent<import("react").ForwardRefExoticComponent<{
    color?: "primary" | "secondary" | "danger" | undefined;
    variant?: "outlined" | "contained" | "ghost" | "ghost_icon" | undefined;
    href?: string | undefined;
    disabled?: boolean | undefined;
    as?: import("react").ElementType<any> | undefined;
    type?: string | undefined;
    fullWidth?: boolean | undefined;
} & import("react").ButtonHTMLAttributes<HTMLButtonElement> & import("react").RefAttributes<HTMLButtonElement>>, any, {}, never>;
export declare const Dg4Field: import("styled-components").StyledComponent<"div", any, {}, never>;
export declare const ImportButton: import("styled-components").StyledComponent<import("react").ForwardRefExoticComponent<{
    color?: "primary" | "secondary" | "danger" | undefined;
    variant?: "outlined" | "contained" | "ghost" | "ghost_icon" | undefined;
    href?: string | undefined;
    disabled?: boolean | undefined;
    as?: import("react").ElementType<any> | undefined;
    type?: string | undefined;
    fullWidth?: boolean | undefined;
} & import("react").ButtonHTMLAttributes<HTMLButtonElement> & import("react").RefAttributes<HTMLButtonElement>>, any, {}, never>;
