import { Dispatch, SetStateAction } from "react";
import { ITimeSeries } from "../../models/ITimeSeries";
export declare const GetArtificialLiftName: (value: number | undefined) => string;
export declare const initializeFirstAndLastYear: (dG4: number, timeSeries: (ITimeSeries | undefined)[], setFirstYear: Dispatch<SetStateAction<number | undefined>>, setLastYear: Dispatch<SetStateAction<number | undefined>>) => void;
