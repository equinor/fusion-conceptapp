declare const DashboardView: () => JSX.Element | null;
export default DashboardView;
