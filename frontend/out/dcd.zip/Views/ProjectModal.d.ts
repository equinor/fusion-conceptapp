declare type Props = {
    isOpen: boolean;
    closeModal: Function;
    passedInProject: Components.Schemas.CommonLibraryProjectDto | undefined;
    passedInProjects: Components.Schemas.CommonLibraryProjectDto[] | undefined;
};
declare const ProjectModal: ({ passedInProject, passedInProjects, isOpen, closeModal, }: Props) => JSX.Element;
export default ProjectModal;
