declare enum AssetTypeEnum {
    drainageStrategies = "drainageStrategies",
    explorations = "explorations",
    substructures = "substructures",
    surfs = "surfs",
    topsides = "topsides",
    transports = "transports",
    wellProjects = "wellProjects"
}
export default AssetTypeEnum;
