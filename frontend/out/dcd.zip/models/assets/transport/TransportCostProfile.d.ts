import { ITimeSeries } from "../../ITimeSeries";
export declare class TransportCostProfile implements Components.Schemas.TransportCostProfileDto, ITimeSeries {
    id?: string | undefined;
    startYear?: number;
    values?: number[];
    epaVersion?: string | null;
    currency?: Components.Schemas.Currency | undefined;
    sum?: number | undefined;
    constructor(data?: Components.Schemas.TransportCostProfileDto);
    static fromJSON(data?: Components.Schemas.TransportCostProfileDto): TransportCostProfile | undefined;
}
