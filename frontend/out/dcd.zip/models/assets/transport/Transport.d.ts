import { IAsset } from "../IAsset";
import { TransportCessationCostProfile } from "./TransportCessationCostProfile";
import { TransportCostProfile } from "./TransportCostProfile";
export declare class Transport implements Components.Schemas.TransportDto, IAsset {
    id?: string | undefined;
    name?: string | undefined;
    projectId?: string | undefined;
    costProfile?: TransportCostProfile | undefined;
    cessationCostProfile?: TransportCessationCostProfile | undefined;
    maturity?: Components.Schemas.Maturity | undefined;
    gasExportPipelineLength?: number | undefined;
    oilExportPipelineLength?: number | undefined;
    currency?: Components.Schemas.Currency;
    constructor(data?: Components.Schemas.TransportDto);
    static fromJSON(data: Components.Schemas.SurfDto): Transport;
}
