import { ITimeSeries } from "../../ITimeSeries";
export declare class TransportCessationCostProfile implements Components.Schemas.TransportCessationCostProfileDto, ITimeSeries {
    id?: string;
    startYear?: number;
    values?: number[];
    epaVersion?: string | null;
    currency?: Components.Schemas.Currency | undefined;
    sum?: number | undefined;
    constructor(data?: Components.Schemas.TransportCessationCostProfileDto);
    static fromJSON(data?: Components.Schemas.TransportCessationCostProfileDto): TransportCessationCostProfile | undefined;
}
