export interface IAsset {
    id?: string | undefined;
    name?: string | undefined;
    projectId?: string | undefined;
}
