import { TopsideCostProfile } from "./TopsideCostProfile";
import { TopsideCessationCostProfile } from "./TopsideCessationCostProfile";
import { IAsset } from "../IAsset";
export declare class Topside implements Components.Schemas.TopsideDto, IAsset {
    id?: string | undefined;
    name?: string | undefined;
    projectId?: string | undefined;
    costProfile?: TopsideCostProfile | undefined;
    cessationCostProfile?: TopsideCessationCostProfile | undefined;
    dryWeight?: number | undefined;
    oilCapacity?: number | undefined;
    gasCapacity?: number | undefined;
    facilitiesAvailability?: number | undefined;
    artificialLift?: Components.Schemas.ArtificialLift | undefined;
    maturity?: Components.Schemas.Maturity | undefined;
    currency?: Components.Schemas.Currency;
    constructor(data?: Components.Schemas.TopsideDto);
    static fromJSON(data: Components.Schemas.TopsideDto): Topside;
}
