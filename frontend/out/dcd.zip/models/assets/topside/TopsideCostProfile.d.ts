import { ITimeSeries } from "../../ITimeSeries";
export declare class TopsideCostProfile implements Components.Schemas.TopsideCostProfileDto, ITimeSeries {
    id?: string;
    startYear?: number;
    values?: number[];
    epaVersion?: string | null;
    currency?: Components.Schemas.Currency | undefined;
    sum?: number | undefined;
    constructor(data?: Components.Schemas.TopsideCostProfileDto);
    static fromJSON(data?: Components.Schemas.TopsideCostProfileDto): TopsideCostProfile | undefined;
}
