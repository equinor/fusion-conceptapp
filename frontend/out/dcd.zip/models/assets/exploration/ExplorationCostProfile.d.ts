import { ITimeSeries } from "../../ITimeSeries";
export declare class ExplorationCostProfile implements Components.Schemas.ExplorationCostProfileDto, ITimeSeries {
    id?: string;
    startYear?: number;
    values?: number[];
    epaVersion?: string;
    currency?: Components.Schemas.Currency;
    sum?: number;
    constructor(data?: Components.Schemas.ExplorationCostProfileDto);
    static fromJSON(data?: Components.Schemas.ExplorationCostProfileDto): ExplorationCostProfile | undefined;
}
