import { ITimeSeries } from "../../ITimeSeries";
export declare class GAndGAdminCost implements Components.Schemas.GAndGAdminCostDto, ITimeSeries {
    id?: string;
    startYear?: number;
    values?: number[];
    constructor(data?: Components.Schemas.GAndGAdminCostDto);
    static fromJSON(data?: Components.Schemas.GAndGAdminCostDto): GAndGAdminCost | undefined;
}
