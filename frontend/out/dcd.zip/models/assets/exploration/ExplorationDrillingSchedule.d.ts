import { ITimeSeries } from "../../ITimeSeries";
export declare class ExplorationDrillingSchedule implements Components.Schemas.ExplorationDrillingScheduleDto, ITimeSeries {
    id?: string;
    startYear?: number;
    values?: number[];
    constructor(data?: Components.Schemas.ExplorationDrillingScheduleDto);
    static fromJSON(data?: Components.Schemas.ExplorationDrillingScheduleDto): ExplorationDrillingSchedule | undefined;
}
