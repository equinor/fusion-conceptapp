import { IAsset } from "../IAsset";
import { ExplorationCostProfile } from "./ExplorationCostProfile";
import { ExplorationDrillingSchedule } from "./ExplorationDrillingSchedule";
import { GAndGAdminCost } from "./GAndAdminCost";
export declare class Exploration implements Components.Schemas.ExplorationDto, IAsset {
    id?: string | undefined;
    projectId?: string | undefined;
    name?: string | undefined;
    wellType?: Components.Schemas.WellType | undefined;
    costProfile?: ExplorationCostProfile | undefined;
    drillingSchedule?: ExplorationDrillingSchedule | undefined;
    gAndGAdminCost?: GAndGAdminCost | undefined;
    rigMobDemob?: number | undefined;
    currency?: Components.Schemas.Currency;
    constructor(data?: Components.Schemas.ExplorationDto);
    static fromJSON(data: Components.Schemas.ExplorationDto): Exploration;
}
