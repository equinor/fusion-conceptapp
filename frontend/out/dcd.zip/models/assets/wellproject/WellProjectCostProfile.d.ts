import { ITimeSeries } from "../../ITimeSeries";
export declare class WellProjectCostProfile implements Components.Schemas.WellProjectCostProfileDto, ITimeSeries {
    id?: string;
    startYear?: number;
    values?: number[];
    epaVersion?: string | null;
    currency?: Components.Schemas.Currency | undefined;
    sum?: number | undefined;
    constructor(data?: Components.Schemas.WellProjectCostProfileDto);
    static fromJSON(data?: Components.Schemas.WellProjectCostProfileDto): WellProjectCostProfile | undefined;
}
