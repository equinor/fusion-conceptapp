import { ITimeSeries } from "../../ITimeSeries";
export declare class DrillingSchedule implements Components.Schemas.DrillingScheduleDto, ITimeSeries {
    id?: string;
    startYear?: number;
    values?: number[];
    constructor(data?: Components.Schemas.DrillingScheduleDto);
    static fromJSON(data?: Components.Schemas.DrillingScheduleDto): DrillingSchedule | undefined;
}
