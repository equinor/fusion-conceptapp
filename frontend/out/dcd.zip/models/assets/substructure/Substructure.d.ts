import { SubstructureCostProfile } from "./SubstructureCostProfile";
import { SubstructureCessationCostProfile } from "./SubstructureCessationCostProfile";
import { IAsset } from "../IAsset";
export declare class Substructure implements Components.Schemas.SubstructureDto, IAsset {
    id?: string | undefined;
    name?: string | undefined;
    projectId?: string | undefined;
    costProfile?: SubstructureCostProfile | undefined;
    cessationCostProfile?: SubstructureCessationCostProfile | undefined;
    dryweight?: number | undefined;
    maturity?: Components.Schemas.Maturity | undefined;
    currency?: Components.Schemas.Currency;
    constructor(data?: Components.Schemas.SubstructureDto);
    static fromJSON(data: Components.Schemas.SubstructureDto): Substructure;
}
