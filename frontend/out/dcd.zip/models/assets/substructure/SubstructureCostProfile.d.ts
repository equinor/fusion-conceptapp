import { ITimeSeries } from "../../ITimeSeries";
export declare class SubstructureCostProfile implements Components.Schemas.SubstructureCostProfileDto, ITimeSeries {
    id?: string;
    startYear?: number;
    values?: number[];
    epaVersion?: string | null;
    currency?: Components.Schemas.Currency | undefined;
    sum?: number | undefined;
    constructor(data?: Components.Schemas.SubstructureCostProfileDto);
    static fromJSON(data?: Components.Schemas.SubstructureCostProfileDto): SubstructureCostProfile | undefined;
}
