import { ITimeSeries } from "../../ITimeSeries";
export declare class ProductionProfileGas implements Components.Schemas.ProductionProfileGasDto, ITimeSeries {
    id?: string;
    startYear?: number;
    values?: number[];
    sum?: number;
    constructor(data?: Components.Schemas.ProductionProfileGasDto);
    static fromJson(data?: Components.Schemas.ProductionProfileGasDto): ProductionProfileGas | undefined;
}
