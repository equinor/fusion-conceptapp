import { ITimeSeries } from "../../ITimeSeries";
export declare class ProductionProfileWaterInjection implements Components.Schemas.ProductionProfileWaterInjectionDto, ITimeSeries {
    id?: string;
    startYear?: number;
    values?: number[];
    sum?: number;
    constructor(data?: Components.Schemas.ProductionProfileWaterInjectionDto);
    static fromJson(data?: Components.Schemas.ProductionProfileWaterInjectionDto): ProductionProfileWaterInjection | undefined;
}
