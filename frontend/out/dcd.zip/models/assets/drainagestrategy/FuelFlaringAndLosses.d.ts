import { ITimeSeries } from "../../ITimeSeries";
export declare class FuelFlaringAndLosses implements Components.Schemas.FuelFlaringAndLossesDto, ITimeSeries {
    id?: string;
    startYear?: number;
    values?: number[];
    sum?: number;
    constructor(data?: Components.Schemas.FuelFlaringAndLossesDto);
    static fromJson(data?: Components.Schemas.FuelFlaringAndLossesDto): FuelFlaringAndLosses | undefined;
}
