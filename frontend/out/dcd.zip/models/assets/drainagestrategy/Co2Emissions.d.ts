import { ITimeSeries } from "../../ITimeSeries";
export declare class Co2Emissions implements Components.Schemas.Co2EmissionsDto, ITimeSeries {
    id?: string;
    startYear?: number;
    values?: number[];
    sum?: number;
    constructor(data?: Components.Schemas.Co2EmissionsDto);
    static fromJson(data?: Components.Schemas.Co2EmissionsDto): Co2Emissions | undefined;
}
