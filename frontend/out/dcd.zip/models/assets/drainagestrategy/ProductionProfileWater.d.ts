import { ITimeSeries } from "../../ITimeSeries";
export declare class ProductionProfileWater implements Components.Schemas.ProductionProfileWaterDto, ITimeSeries {
    id?: string;
    startYear?: number;
    values?: number[];
    sum?: number;
    constructor(data?: Components.Schemas.ProductionProfileWaterDto);
    static fromJson(data?: Components.Schemas.ProductionProfileWaterDto): ProductionProfileWater | undefined;
}
