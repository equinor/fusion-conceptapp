import { ITimeSeries } from "../../ITimeSeries";
export declare class NetSalesGas implements Components.Schemas.NetSalesGasDto, ITimeSeries {
    id?: string;
    startYear?: number;
    values?: number[];
    sum?: number;
    constructor(data?: Components.Schemas.NetSalesGasDto);
    static fromJson(data?: Components.Schemas.NetSalesGasDto): NetSalesGas | undefined;
}
