import { ITimeSeries } from "../../ITimeSeries";
export declare class ProductionProfileNGL implements Components.Schemas.ProductionProfileNGLDto, ITimeSeries {
    id?: string;
    startYear?: number;
    values?: number[];
    sum?: number;
    constructor(data?: Components.Schemas.ProductionProfileNGLDto);
    static fromJson(data?: Components.Schemas.ProductionProfileNGLDto): ProductionProfileNGL | undefined;
}
