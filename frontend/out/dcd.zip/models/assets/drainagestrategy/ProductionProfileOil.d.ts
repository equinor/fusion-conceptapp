import { ITimeSeries } from "../../ITimeSeries";
export declare class ProductionProfileOil implements Components.Schemas.ProductionProfileOilDto, ITimeSeries {
    id?: string;
    startYear?: number;
    values?: number[];
    sum?: number;
    constructor(data?: Components.Schemas.ProductionProfileOilDto);
    static fromJson(data?: Components.Schemas.ProductionProfileOilDto): ProductionProfileOil | undefined;
}
