import { SurfCostProfile } from "./SurfCostProfile";
import { SurfCessationCostProfile } from "./SurfCessationCostProfile";
import { IAsset } from "../IAsset";
export declare class Surf implements Components.Schemas.SurfDto, IAsset {
    id?: string | undefined;
    name: string | undefined;
    projectId?: string | undefined;
    costProfile?: SurfCostProfile | undefined;
    cessationCostProfile: SurfCessationCostProfile | undefined;
    maturity?: Components.Schemas.Maturity | undefined;
    infieldPipelineSystemLength?: number | undefined;
    umbilicalSystemLength?: number | undefined;
    artificialLift?: Components.Schemas.ArtificialLift | undefined;
    riserCount?: number | undefined;
    templateCount?: number | undefined;
    producerCount?: number | undefined;
    gasInjectorCount?: number | undefined;
    waterInjectorCount?: number | undefined;
    productionFlowline?: Components.Schemas.ProductionFlowline | undefined;
    currency?: Components.Schemas.Currency;
    constructor(data?: Components.Schemas.SurfDto);
    static fromJSON(data: Components.Schemas.SurfDto): Surf;
}
