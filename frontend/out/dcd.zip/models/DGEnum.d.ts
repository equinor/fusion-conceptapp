declare enum DGEnum {
    DG0 = "DG0Date",
    DG1 = "DG1Date",
    DG2 = "DG2Date",
    DG3 = "DG3Date",
    DG4 = "DG4Date"
}
export default DGEnum;
