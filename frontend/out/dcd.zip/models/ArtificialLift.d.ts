export declare class ArtificialLift {
    private type;
    constructor(type: number);
    toString(): string | undefined;
}
