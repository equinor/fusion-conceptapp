export interface ITimeSeries {
    id?: string;
    startYear?: number;
    values?: number[];
    sum?: number | undefined;
}
