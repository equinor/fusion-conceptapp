export declare class PhysicalUnit {
    private phase;
    constructor(phase: number);
    static parseJSON(value: PhysicalUnit): PhysicalUnit;
    valueOf(): number;
    toString(): string | undefined;
}
