export declare class ProjectCategory {
    private category;
    constructor(category: number);
    toString(): string | undefined;
}
