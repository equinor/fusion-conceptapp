export declare class Currency {
    private phase;
    constructor(phase: number);
    static parseJSON(value: Currency): Currency;
    valueOf(): number;
    toString(): string | undefined;
}
