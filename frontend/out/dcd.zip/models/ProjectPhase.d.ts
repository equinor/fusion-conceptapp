export declare class ProjectPhase {
    private phase;
    constructor(phase: number);
    static parseJSON(value: ProjectPhase): ProjectPhase;
    valueOf(): number;
    toString(): string | undefined;
}
