declare type AnnualMetricConstructor = {
    id: any;
    value: number;
    year: number;
};
export declare class AnnualMetric {
    id: string;
    value: number;
    year: number;
    constructor(data: AnnualMetricConstructor);
    static fromJSON(data: AnnualMetricConstructor): AnnualMetric;
}
export {};
